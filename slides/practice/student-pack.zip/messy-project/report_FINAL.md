# Orders report — final

We received four orders, with total revenue of CHF 50.00.
Average order value was CHF 12.50.

Numbers copied from the console before sending the folder.
