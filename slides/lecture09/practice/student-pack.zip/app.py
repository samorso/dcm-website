"""Week 11 starter: a browser interface over the unchanged Week 8-10 pipeline."""
import streamlit as st

from pipeline import compare, extract
from validation import load

st.set_page_config(page_title="DCM Population Explorer", layout="wide")
st.title("Population Explorer")
st.caption("Frozen World Bank population snapshot | 2023 and 2024 | persons")

try:
    table = extract(load())
    growth = compare(table)
except (ValueError, FileNotFoundError) as error:
    st.error(f"The data could not be used: {error}")
    st.stop()

country_names = {
    row.country_code: row.country_name
    for row in table.itertuples(index=False)
}
code = st.selectbox(
    "Choose a country",
    sorted(country_names),
    format_func=lambda value: country_names[value],
)
st.write(f"Selected country: {country_names[code]}")
st.dataframe(growth, hide_index=True)

# ACTIVITY B: add a 2024 population metric and a 2023/2024 bar chart.
# Use the selected code. The calculation already lives in compare().
